<template >
    <aside class="menu">
        <p class="menu-lable-text">
            General
        </p>
        <ul class="menu-list">
            <li><a>Dashboard</a></li>                   
        </ul>
        <p class="menu-lable-text">
            Administration
        </p>
        <ul class="menu-list">
            <li><a>Issuers</a></li>            
             <li><a>Users</a></li>
            <li><a>Roles</a></li>
            <li><a>Permissions</a></li>
            <li><a>Resources</a></li>
            <li><a>Reports</a></li>
            <li><a>Events</a></li>
        </ul>
        <p class="menu-lable-text">
            Communication
        </p>
        <ul class="menu-list">
            <li><a>In-bound</a></li>
            <li><a>Out-bound</a></li>
            <li><a>Generic</a></li>
        </ul>
   </aside>
</template>

<script>
export default {
  name: "Sidebar",
  data() {
    return {
      active: true
    };
  },
  prop: {},
  mounted() {},
  methods: {}
};
</script>



<style lang="scss">
.menu-lable-text {
  color: #40c1bb;
  font-size: 1.1em;
  letter-spacing: 0.1em;
  text-transform: uppercase;
}
.menu-lable-text:not(:last-child) {
  margin-bottom: 0.85em;
}
</style>