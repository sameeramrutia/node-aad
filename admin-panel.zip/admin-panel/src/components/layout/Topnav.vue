<template>
    <nav class="navbar menu-bg" role="navigation" aria-label="main navigation">
        <a class="navbar-item p-left-20" @click="toggleNav()">
            <i class="fa fa-bars fa-2x"></i>
        </a>
        <a class="navbar-item">
            <img src="https://www.msci.com/msci-theme/images/msci-logo.png">
        </a>
        <div class="navbar-item header-title">
            <h2 style="color:#37617A;">ESG ICP Admin Panel</h2>
        </div>
        <div class="navbar-end">
            <div class="navbar-item" >
                <i class="fa fa-bell fa-2x"></i>
            </div>
            <div class="navbar-item">                
                    User Name                
            </div>
            <div class="navbar-item" >
                <i class="fa fa-power-off fa-2x"></i>
            </div>
        </div>
    </nav>
</template>
<script>
export default {
  name: "Topnav",
  data() {
    return {};
  },
  methods: {
    toggleNav() {
        this.$parent.$emit('toggleNav');
    }
  }
};
</script>
<style lang="scss" scoped>
.p-left-20{
    padding-left: 20px;
}
.header-title{
font-size:1.55em;
}
</style>


