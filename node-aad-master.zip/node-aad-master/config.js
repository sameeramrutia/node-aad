exports.creds = {
    clientID: 'c2d762b4-d18c-463a-93fd-12bfdc8eae72',
    clientSecret: 'd}`T7&i+b~a95ig750~=5a13',
    audience: 'c2d762b4-d18c-463a-93fd-12bfdc8eae72',    
    redirectUrl: 'http://localhost:3000/auth/callback',
    // you cannot have users from multiple tenants sign in to your server unless you use the common endpoint
    // example: https://login.microsoftonline.com/common/.well-known/openid-configuration
    identityMetadata: 'https://login.microsoftonline.com/msciaadb2ctest.onmicrosoft.com/v2.0/.well-known/openid-configuration?p=B2C_1_sign-in-up',
    validateIssuer: true, // if you have validation on, you cannot have users from multiple tenants sign in to your server
    passReqToCallback: false,
    responseType: 'code id_token', // for login only flows use id_token. For accessing resources use `id_token code
    responseMode: 'form_post', // For login only flows we should have token passed back to us in a POST
    loggingLevel: 'info', // valid are 'info', 'warn', 'error'. Error always goes to stderr in Unix.
    scope: ['email', 'profile'], // additional scopes you may wish to pass,
    allowHttpForRedirectUrl: true
};

/**
 *  clientID: process.env.CLIENT_ID,
    clientSecret: process.env.CLIENT_SECRET,
    audience: process.env.AUDIENCE,    
    redirectUrl: process.env.REDIRECT_URL,
    // you cannot have users from multiple tenants sign in to your server unless you use the common endpoint
    // example: https://login.microsoftonline.com/common/.well-known/openid-configuration
    identityMetadata: process.env.IDENTITY_METADATA,
    validateIssuer: true, // if you have validation on, you cannot have users from multiple tenants sign in to your server
    passReqToCallback: false,
    responseType: 'id_token', // for login only flows use id_token. For accessing resources use `id_token code
    responseMode: 'form_post', // For login only flows we should have token passed back to us in a POST
    loggingLevel: 'info', // valid are 'info', 'warn', 'error'. Error always goes to stderr in Unix.
    scope: ['email', 'profile'], // additional scopes you may wish to pass,
    allowHttpForRedirectUrl: true
 */