const express = require('express');
const router = require('express').Router();
const path = require('path');
const favicon = require('serve-favicon');
const logger = require('morgan');
const cookieParser = require('cookie-parser');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');
const session = require('express-session');
const http = require('http');
const https = require('https');
const fs = require('fs');
const util = require('util');

const passport = require('passport');
const OIDCStrategy = require('passport-azure-ad').OIDCStrategy;

const config = require('./config');
const index = require('./routes/index');

//const HttpProxyAgent = require('http-proxy-agent');


// array to hold logged in users
var users = [];

class WebServer {
  initialize() {
    
       


    //   To support persistent login sessions, Passport needs to be able to
    //   serialize users into and deserialize users out of the session.  Typically,
    //   this will be as simple as storing the user ID when serializing, and finding
    //   the user by ID when deserializing.
    passport.serializeUser(function (user, done) {
      //done(null, user.oid);
      done(null, user);
    });

    /*
    passport.deserializeUser(function (id, done) {
      findByOID(id, function (err, user) {
        done(err, user);
      });
    });
    */

    passport.deserializeUser(function (user, done) {
      done(null, user);
    });

    var findByOID = function (oid, fn) {
      for (var i = 0, len = users.length; i < len; i++) {
        var user = users[i];

        if (user.oid === oid) {
          return fn(null, user);
        }
      }
      console.log("Did not find user by OID: " + oid);
      return fn(null, null);
    };

    // Use the OIDCStrategy within Passport. (Section 2) 
    // 
    //   Strategies in passport require a `validate` function, which accept
    //   credentials (in this case, an OpenID identifier), and invoke a callback
    //   with a user object.
    

    passport.use(new OIDCStrategy({
      callbackURL: config.creds.returnURL,
      redirectUrl: config.creds.redirectUrl,
      realm: config.creds.realm,
      clientID: config.creds.clientID,
      clientSecret: config.creds.clientSecret,
      oidcIssuer: config.creds.issuer,
      identityMetadata: config.creds.identityMetadata,
      skipUserProfile: config.creds.skipUserProfile,
      responseType: config.creds.responseType,
      responseMode: config.creds.responseMode,
      scope: config.creds.scope,
      allowHttpForRedirectUrl: config.creds.allowHttpForRedirectUrl
    },
    function (iss, sub, profile, accessToken, refreshToken, done) {
      console.log(profile);
      if (!profile.oid) {

        console.log(util.inspect(profile));
        return done(new Error("No OID found"), null);
      }
      // asynchronous verification, for effect...
      process.nextTick(function () {
        //chk with my underlying system if user exists with our records.
        console.log(profile.emails[0]);

        profile.authorized = true;
        return done(null, profile);
      });
    }
  ));




    var app = express();

    // view engine setup
    app.set('views', path.join(__dirname, 'views'));
    app.set('view engine', 'jade');

    // uncomment after placing your favicon in /public
    //app.use(favicon(path.join(__dirname, 'public', 'favicon.ico')));
    app.use(logger('dev'));
    app.use(methodOverride());
    app.use(bodyParser.json());
    app.use(bodyParser.urlencoded({
      extended: true
    }));
    app.use(cookieParser());
    app.use(session({
      secret: 'keyboard cat',
      resave: true,
      saveUninitialized: false
    }));
    //Initialize Passport
    app.use(passport.initialize());
    app.use(passport.session());
    app.use(express.static(path.join(__dirname, 'public')));




    // Our Auth routes (section 3)

    // GET /auth/openid
    //   Use passport.authenticate() as route middleware to authenticate the
    //   request. The first step in OpenID authentication involves redirecting
    //   the user to their OpenID provider. After authenticating, the OpenID
    //   provider redirects the user back to this application at
    //   /auth/openid/return.

    /*
    app.get('/auth/openid',
      passport.authenticate('azuread-openidconnect', {
        failureRedirect: '/login'
      }),
      function (req, res) {
        console.log('Authentication was called in the Sample');
        res.redirect('/');
      });
    */

    // GET /auth/openid/return
    //   Use passport.authenticate() as route middleware to authenticate the
    //   request. If authentication fails, the user is redirected back to the
    //   sign-in page. Otherwise, the primary route function is called,
    //   which, in this example, redirects the user to the home page.
    app.get('/auth/callback',
      passport.authenticate('azuread-openidconnect', {
        failureRedirect: '/login'
      }),
      function (req, res) {
        console.log('We received a return from AzureAD.');
        res.redirect('/');
      });

    // POST /auth/openid/return
    //   Use passport.authenticate() as route middleware to authenticate the
    //   request. If authentication fails, the user is redirected back to the
    //   sign-in page. Otherwise, the primary route function is called,
    //   which, in this example, redirects the user to the home page.
    app.post('/auth/callback',
      passport.authenticate('azuread-openidconnect', {
        failureRedirect: '/login'
      }),
      function (req, res) {
        if (req.user.authorized == true) {
          console.log('We received authorized flag.');
          res.redirect('/');
        } else {
          req.user = null;
          //req.logout();
          res.redirect('/unauthorized');
        }
      });



    //Routes (section 4)

    app.get('/', index);

    app.get('/test', index);


    app.get('/account', function (req, res) {
      res.render('account', {
        user: req.user
      });
    });

    app.get('/login',
      passport.authenticate('azuread-openidconnect', {
        failureRedirect: '/login'
      }),
      function (req, res) {
        console.log('Login was called in the Sample');
        res.redirect('/');
      });

    app.get('/logout', function (req, res) {
      req.logout();
      res.redirect('/');
    });

    app.get('/unauthorized', (req, res) => {
      // TODO: create a page
      res.send("<p> The email link  is : <a href='mailto:samantha.sueping@msci.com?Subject=Authorization%20request&body=Hi Team, please authorize me to access Issuer Communication Portal. My email address is :' target='_top'>here</a></p>");
    }, index);

    // catch 404 and forward to error handler
    app.use(function (req, res, next) {
      var err = new Error('Not Found');
      err.status = 404;
      next(err);
    });

    // error handler
    app.use(function (err, req, res, next) {
      // set locals, only providing error in development
      res.locals.message = err.message;
      res.locals.error = req.app.get('env') === 'development' ? err : {};

      // render the error page
      res.status(err.status || 500);
      res.render('error');
    });


    // Simple route middleware to ensure user is authenticated. (section 4)

    //   Use this route middleware on any resource that needs to be protected. If
    //   the request is authenticated (typically via a persistent sign-in session),
    //   the request proceeds. Otherwise, the user is redirected to the
    //   sign-in page.
    function ensureAuthenticated(req, res, next) {
      //if expiery passed exp: 
      if (req.isAuthenticated()) {
        return next();
      }
      res.redirect('/login')
    }

    // This line is from the Node.js HTTPS documentation.
    /*
    var options = {
      key: fs.readFileSync('./key.pem'),
      cert: fs.readFileSync('./cert.pem')
    };
    */

    http.createServer(app).listen(3000, () => {
      console.log('server is up and running at 3000');
    });
    //https.createServer(options, app).listen(443);
  }
}

module.exports = new WebServer();