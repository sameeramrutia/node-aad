# AzureAD with Node.js 7.x
This solution demonstrates a simple Node.js app built with minimum version 7.4.0.  To see a tutorial using Node.js version 4.x, see https://docs.microsoft.com/en-us/azure/active-directory/develop/active-directory-devquickstarts-openidconnect-nodejs.

All about passport stretagy : https://github.com/AzureAD/passport-azure-ad

# Installation
This solution requires Node Js 7.x installed on machine. also Visual studio Code is recommended editor to work upon this solution.

> also install this VS Code plugin to read ***readme.md***
> https://marketplace.visualstudio.com/items?itemName=bierner.markdown-preview-github-styles


# Steps to start project

* open this project folder in VS Code.
* Press Ctrl + ` (to enable in - built terminal. )
* run command  ***npm install***
* once npm install all packages successfully, run command ***node server.js***
* now go to the browser, clean all cookies, and go to the http://localhost:3000
* if you want to debug this project, click on the debug icon in the left panel of VS Code
* in .vscode/launch.json is already having a debug config in-built.
  

