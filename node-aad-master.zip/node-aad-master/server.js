const webServer = require('./app');

startup();

function startup() {
    webServer.initialize();
}