
class Node {
    constructor(info) {
        this.info = info;
        this.next = null;
    }
}

class LinkedList {
    constructor() {
        this.head = null;
        this.size = 0;
    }
}

LinkedList.prototype.insertNodeAtEnd = function (info) {
    let node = new Node(info);
    if (this.head == null) {
        this.head = node;
        this.size += 1;
    }
    else {
        let p = this.head;
        while (p.next != null) {
            p = p.next;
        }
        p.next = node;
        this.size += 1;
    }
}

LinkedList.prototype.createLinkedList = function (inputArray) {
    for (let i = 0; i < inputArray.length; i++) {
        this.insertNodeAtEnd(inputArray[i]);
    }
}

LinkedList.prototype.printLinkedList = function () {
    if (this.head != null) {
        let p = this.head;
        let str = "";
        while (p.next != null) {
            str = str + `[ ${p.info} ]-->`;
            p = p.next;
        }
        str = str + `[ ${p.info} ]---|EOL`;
        console.log(str + ' - Length : ' + this.size);
    }
}

LinkedList.prototype.insertNodeAtStart = function (info) {
    let temp = new Node(info);
    if (this.head != null) {
        temp.next = this.head;
        this.head = temp;
        this.size += 1;
    }
}
LinkedList.prototype.insertNodeAfterReferenceInfo = function (info, refInfo) {
    let temp = new Node(info);
    let p = this.head;
    while (p.next != null) {
        if (p.info == refInfo) {
            temp.next = p.next;
            p.next = temp;
            this.size += 1;
            break;
        }
        p = p.next; //loop moves traget to the next node.
    }
}
LinkedList.prototype.insertNodeBeforeReferenceInfo = function (info, refInfo) {
    let temp = new Node(info);
    let p = this.head;
    while (p.next != null) {
        if (p.next.info == refInfo) {
            temp.next = p.next;
            p.next = temp;
            this.size += 1;
            break;
        }
        p = p.next;
    }
}
LinkedList.prototype.insertNodeAtGivenPosition = function (info, position) {
    let p = this.head;
    let temp = new Node(info);
    if (position == 1) {
        temp.next = p;
        p = temp;
        return;
    }
    for (let i = 1; i < position - 1 && p.next != null; i++) {
        p = p.next;
    }
    temp.next = p.next;
    p.next = temp;
    this.size += 1;
}

LinkedList.prototype.deleteFirstnode = function () {
    let p = this.head;
    if (p.next == null) {
        return;
    }
    else {
        this.head = this.head.next;
        this.size -= 1;
    }
}

LinkedList.prototype.deleteNode = function (info) {
    if (this.head.info == info) {
        this.head = this.head.next;
    }
    else {
        let p = this.head;
        while (p.next != null) {
            if (p.next.info == info) {
                break;
            }
            p = p.next; // increment loop by moving pointer to the next.
        }
        p.next = p.next.next;
    }
}
LinkedList.prototype.printLinkedListOperationSteps = function (obj) {
    if (obj != null) {
        let p = obj;
        let str = "";
        while (p.next != null) {
            str = str + `[ ${p.info} ]-->`;
            p = p.next;
        }
        str = str + `[ ${p.info} ]---|EOL`;
    }
}

LinkedList.prototype.reverse = function () {
    let prev = null, p = this.head, next = null;
    while (p != null) {
        next = p.next;
        p.next = prev;
        prev = p;
        p = next;
        this.printLinkedListOperationSteps(p);
    }
    p = prev;
    this.head = p; // asgin temp to the original ll object.    
}
LinkedList.prototype.insertCycle = function (info) {
    let p = this.head;
    let prev = null;
    let px = null;
    while (p != null) {      
        if(p.info == info){
            px = p;
        }
        prev = p;
        p = p.next;
    }
    if(px !== null){
        prev.link = px;
    }
}
LinkedList.prototype.hasCycle = function () {
    let slow = this.head;
    let fast = this.head;
    let cycleFlag = false;
    while (fast != null && fast.next != null) {
        slow = slow.next;
        fast = fast.next.next;
        if (slow == fast) {
           cycleFlag = true;
                       break;
        }
    }

    if(cycleFlag == true){
        console.log(`this linked list has cycle at ${slow.info}`);
    }
    else{
        console.log(`No Cycle found.`);
    }
}

module.exports = { Node: Node, LinkedList: LinkedList }