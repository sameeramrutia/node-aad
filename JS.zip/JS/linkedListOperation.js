
const Node = require('./linkedList').Node;
const LinkedList = require('./linkedList').LinkedList;


let objLinkedList = new LinkedList();
objLinkedList.createLinkedList([4,2,5,7,90]);
objLinkedList.printLinkedList();

objLinkedList.insertNodeAtStart(20);
objLinkedList.printLinkedList();

objLinkedList.insertNodeAtEnd(44);
objLinkedList.printLinkedList();

objLinkedList.insertNodeAfterReferenceInfo(22,4);
objLinkedList.printLinkedList();

objLinkedList.insertNodeBeforeReferenceInfo(60,90);
objLinkedList.printLinkedList();

objLinkedList.insertNodeAtGivenPosition(35,5);
objLinkedList.printLinkedList();

//objLinkedList.insertNodeAtGivenPosition(18,1);
//objLinkedList.printLinkedList();

objLinkedList.deleteNode(7);
objLinkedList.printLinkedList();

objLinkedList.reverse();
objLinkedList.printLinkedList();

objLinkedList.insertCycle(35);
objLinkedList.hasCycle();
//objLinkedList.printLinkedList();