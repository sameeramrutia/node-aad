class Node {
    constructor(info) {
        this.prev = null;
        this.info = info;
        this.next = null;
    }
}

class DublyLinkedList {
    constructor() {
        this.head = null;
        this.size = 0;
    }
}

DublyLinkedList.prototype.createList = function (inputArray) {
    for (let i = 0; i < inputArray.length; i++) {
        this.insertAtEnd(inputArray[i]);
    }
}

DublyLinkedList.prototype.insertAtStart = function (info) {
    let temp = new Node(info);
    if (this.head == null) {
        this.head = temp;
        this.size += 1;
    }
    else {
        temp.next = this.head;
        this.head.prev = temp;
        this.head = temp;
        this.size += 1;
    }
}

DublyLinkedList.prototype.insertAtEnd = function (info) {
    let temp = new Node(info);
    let p = this.head;
    if (this.head === null) {
        this.head = temp;
        this.size += 1;
        return;
    }

    while (p.next != null) {
        p = p.next;
    }
    p.next = temp;
    temp.prev = p;
    this.size += 1;
}

DublyLinkedList.prototype.insertAfterNode = function (info, refInfo) {
    let temp = new Node(info);
    let p = this.head;
    if (this.head === null) {
        this.head = temp;
        this.size += 1;
        return;
    }

    while (p.next != null) {
        if (p.info == refInfo) {
            temp.next = p.next; // assign temp next with the next node of reference node(the node with reference).
            temp.prev = p; // 
            p.next.prev = temp;
            p.next = temp;
            this.size += 1;
        }
        p = p.next;
    }
}

DublyLinkedList.prototype.insertBeforeNode = function (info, refInfo) {
    let temp = new Node(info);
    let p = this.head;
    if (this.head === null) {
        this.head = temp;
        return;
    }
    while(p.next != null){
        if(p.info == refInfo){
            temp.prev = p.prev;
            temp.next = p;
            p.prev.next = temp;
            p.prev = temp;
            this.size += 1;
           // console.log(`Node will be inserted before this: ${p.info}`);
        }
        p = p.next;
    }
}

DublyLinkedList.prototype.deleteFromStart = function(){
    let p = this.head;
    if(p != null){
        this.head = p.next;
        this.head.prev = null;
        this.size -= 1;
    }
}
DublyLinkedList.prototype.deleteNodeInBetween = function(refInfo){
    let p = this.head;
    while(p.next != null){
        if(p.info == refInfo){
            p.prev.next = p.next;
            p.next.prev = p.prev;
            this.size -= 1;
        }
        p = p.next;
    }
}

DublyLinkedList.prototype.deleteNodeAtLast = function(){
    let p = this.head;
    while(p.next != null){
        p = p.next;
    }
    p.prev.next = null;
    this.size -= 1;
}

DublyLinkedList.prototype.reverse =function(){
    let p1 = this.head;
    let p2 = p1.next;
    p1.next = null;
    p1.prev = p2;
    while(p2 != null){
        p2.prev = p2.next;
        p2.next = p1;
        p1 = p2;
        p2 = p2.prev;
    }
   this.head = p1;
}

DublyLinkedList.prototype.printList = function () {
    if (this.head != null) {
        let p = this.head;
        let str = "";
        while (p.next != null) {
            str = str + `[ ${p.info} ]<-->`;
            p = p.next;
        }
        str = str + `[ ${p.info} ]---|EOL`;
        console.log(str + ' - Length : ' + this.size);
    }
}

module.exports = { Node: Node, DublyLinkedList: DublyLinkedList }