const Node = require('./doublyLinkedList').Node;
const DublyLinkedList = require('./doublyLinkedList').DublyLinkedList;

var dll = new DublyLinkedList();

dll.createList([1,2,3,4,5,6]);
dll.insertAfterNode(12,5);
dll.insertBeforeNode(11,4);
dll.printList();
dll.deleteFromStart();
dll.printList();
dll.deleteNodeInBetween(5);
dll.printList();
dll.reverse();
dll.printList();