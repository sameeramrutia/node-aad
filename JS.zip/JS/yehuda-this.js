//semantics of 'this' in function invocation is confusing.
/* the same confusion can be cleared up by understanding the core function premitive and then 
looking at all other ways of invoking a function as sugar on top of that primitive.*/ 

function hello(things){
    console.log(this + " says hello" + things);
}

hello.call('Sameer','world');
//you can think of all other function call as desugaring to this primitive.

hello.call(global,'world');

let x = 2;
x = x << 2;
console.log(x);
let y = x>>1;
console.log(y);